export interface Client {
  country: string,
  client: string,
  balance: number,
  moneda: string
}