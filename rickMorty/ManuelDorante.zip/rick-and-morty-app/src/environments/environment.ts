export const environment = {
  production: false,
  auth: {
    domain: 'dev-j2cizir5.us.auth0.com',
    clientId: '0vTCsj1v0oJCH0BA4HAEVKBLVsiBWdmB',
    redirectUri: window.location.origin,
  },
};
